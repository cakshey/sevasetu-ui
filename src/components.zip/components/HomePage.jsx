import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import "./HomePage.css";

// ✅ Category icons (from public/assets/icons)
const categories = [
  { title: "Women's Salon & Spa", icon: "/assets/icons/women-salon.png" },
  { title: "Men's Salon & Massage", icon: "/assets/icons/men-salon.png" },
  { title: "Cleaning & Pest Control", icon: "/assets/icons/cleaning.png" },
  { title: "Electrician, Plumber & Carpenter", icon: "/assets/icons/electrician.png" },
  { title: "Painting & Waterproofing", icon: "/assets/icons/painting.png" },
  { title: "Native Water Purifier", icon: "/assets/icons/purifier.png" },
  { title: "AC & Appliance Repair", icon: "/assets/icons/ac-repair.png" },
  { title: "Wall Makeover by Revamp", icon: "/assets/icons/wall-makeover.png" },
];

// ✅ Right side image grid (Service highlights)
const highlights = [
  {
    title: "Domestic Staff",
    img: "/assets/domestic-staff.jpg",
    caption: "Housemaid, Cook, Driver, Security Guard",
  },
  {
    title: "Pest Control",
    img: "/assets/pest-control.jpg",
    caption: "Cockroach, Termite, Bed Bug, Disinfection",
  },
  {
    title: "Appliance Repair",
    img: "/assets/appliance-repair.jpg",
    caption: "Electrical, Plumbing, AC, Appliance Repair",
  },
  {
    title: "Home Painting",
    img: "/assets/home-painting.jpg",
    caption: "Home, Kitchen, Bathroom, Sofa, Mattress",
  },
];

const HomePage = () => {
  const navigate = useNavigate();
  const [searchTerm, setSearchTerm] = useState(""); // ✅ Added search state

  // ✅ Handles category click → navigates with URL param
  const handleCategoryClick = (category) => {
    const encoded = encodeURIComponent(category);
    navigate(`/services?category=${encoded}`);
  };

  // ✅ Filter categories based on search input
  const filteredCategories = categories.filter((cat) =>
    cat.title.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="home-container">
      {/* LEFT SIDE */}
      <div className="home-left">
        <h1>Home services at your doorstep</h1>
        <p>
          SevaSetu helps you connect with trusted home and care services —
          faster, safer, and smarter.
        </p>

        <div className="category-section">
          <h3>What are you looking for?</h3>

          {/* ✅ Search Bar */}
          <div className="search-container">
            <input
              type="text"
              className="search-input"
              placeholder="Search services..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>

          {/* ✅ Filtered Category Grid */}
          <div className="category-grid">
            {filteredCategories.length > 0 ? (
              filteredCategories.map((cat, index) => (
                <div
                  key={index}
                  className="category-card"
                  onClick={() => handleCategoryClick(cat.title)}
                >
                  <img src={cat.icon} alt={cat.title} className="category-img" />
                  <p className="category-label">{cat.title}</p>
                </div>
              ))
            ) : (
              <p style={{ textAlign: "center", color: "#666" }}>
                No services found.
              </p>
            )}
          </div>
        </div>
      </div>

      {/* RIGHT SIDE */}
      <div className="home-right">
        <div className="image-grid">
          {highlights.map((img, index) => (
            <div className="image-card" key={index}>
              <img src={img.img} alt={img.title} />
              <div className="image-caption">
                <strong>{img.title}</strong>
                <br />
                {img.caption}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default HomePage;
