import React, { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { auth, signInWithGoogle, logoutUser } from "../firebaseAuth";
import "./Navbar.css";

export default function Navbar() {
  const [user, setUser] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    const unsubscribe = auth.onAuthStateChanged((u) => setUser(u));
    return unsubscribe;
  }, []);

  const handleLogin = async () => {
    const loggedUser = await signInWithGoogle();
    if (loggedUser) {
      setUser(loggedUser);
      alert(`Welcome, ${loggedUser.displayName}!`);
    }
  };

  const handleLogout = async () => {
    await logoutUser();
    setUser(null);
    navigate("/");
  };

  return (
    <header className="navbar">
      <div className="nav-left" onClick={() => navigate("/")}>
        💜 <span className="brand">SevaSetu India</span>
      </div>

      <nav className="nav-links">
        <Link to="/">Home</Link>
        <Link to="/services">Services</Link>
        <Link to="#">About</Link>
        <Link to="#">Contact</Link>
      </nav>

      <div className="nav-right">
        {user ? (
          <div className="user-info">
            {user.photoURL && (
              <img src={user.photoURL} alt="User" className="user-avatar" />
            )}
            <span className="user-name">
              {user.displayName || "User"}
            </span>
            <button className="logout-btn" onClick={handleLogout}>
              Logout
            </button>
          </div>
        ) : (
          <button className="login-btn" onClick={handleLogin}>
            Login with Google
          </button>
        )}
      </div>
    </header>
  );
}
