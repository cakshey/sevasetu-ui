import React, { useState } from "react";
import { addDoc, collection, serverTimestamp } from "firebase/firestore";
import { getFunctions, httpsCallable } from "firebase/functions";
import { db } from "../firebase"; // your existing firebase export
import "./LaunchingSoonWidget.css";

/*
  LaunchingSoonWidget
  - Saves entries to Firestore collection "waitlist"
  - Calls a Cloud Function "notifyWaitlist" (optional) to send email/notification
  - Has a placeholder for Phone OTP verification (Firebase Auth) - see comments below
*/

export default function LaunchingSoonWidget() {
  const [form, setForm] = useState({
    name: "",
    phone: "",
    district: "Lucknow",
    email: "",
    role: "Customer",
  });
  const [loading, setLoading] = useState(false);
  const [saved, setSaved] = useState(false);
  const [error, setError] = useState("");
  const [otpSent, setOtpSent] = useState(false);
  const [otpVerified, setOtpVerified] = useState(false);
  const [otp, setOtp] = useState("");

  const districts = [
    "Lucknow",
    "Kanpur",
    "Allahabad",
    "Indore",
    "Other",
  ];

  function handleChange(e) {
    setForm((s) => ({ ...s, [e.target.name]: e.target.value }));
  }

  // Submit handler: save to Firestore + call function to notify
  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    if (!form.name || !form.phone) {
      setError("Please enter name and mobile number.");
      return;
    }

    setLoading(true);
    try {
      // 1) Save to Firestore (collection "waitlist")
      await addDoc(collection(db, "waitlist"), {
        name: form.name,
        phone: form.phone,
        district: form.district,
        email: form.email || null,
        role: form.role || "Customer",
        createdAt: serverTimestamp(),
        otpVerified: otpVerified,
      });

      // 2) Optional: call a cloud function to notify admin / send email
      try {
        const functions = getFunctions();
        const notifyWaitlist = httpsCallable(functions, "notifyWaitlist");
        await notifyWaitlist({
          name: form.name,
          phone: form.phone,
          district: form.district,
          email: form.email || "",
          role: form.role,
        });
      } catch (fnErr) {
        // If function missing, ignore — Firestore entry is primary
        // console.warn("notifyWaitlist function error:", fnErr);
      }

      setSaved(true);
      setForm({
        name: "",
        phone: "",
        district: "Lucknow",
        email: "",
        role: "Customer",
      });
      setOtp("");
      setOtpSent(false);
      setOtpVerified(false);
    } catch (err) {
      console.error(err);
      setError("Failed to submit. Try again.");
    } finally {
      setLoading(false);
    }
  };

  /* -------------------------------------------
     OTP placeholder logic
     -------------------------------------------
     This component includes a simple placeholder UI for "Send OTP / Verify OTP"
     To actually send and verify OTPs you must implement Firebase Phone Auth.
     Minimal steps (high-level):
       1) enable Phone sign-in in Firebase Console (Auth > Sign-in method)
       2) implement reCAPTCHA verifier (`window.recaptchaVerifier`)
       3) call `signInWithPhoneNumber(auth, phoneNumber, appVerifier)` to send OTP
       4) confirm result with `confirmationResult.confirm(code)` to verify
     I left a small mock flow below so you can wire the real flow later.
  -------------------------------------------- */

  const handleSendOtpMock = async () => {
    // Replace this with real phone auth flow
    if (!form.phone) {
      setError("Enter mobile number to send OTP");
      return;
    }
    setError("");
    setOtpSent(true);
    // real implementation: call Firebase phone auth to send OTP
  };

  const handleVerifyOtpMock = async () => {
    // Replace with confirmationResult.confirm(otp) logic from Firebase phone auth
    if (otp.length < 4) {
      setError("Enter valid OTP");
      return;
    }
    setOtpVerified(true);
    setError("");
  };

  return (
    <div className="launching-widget-wrapper">
      <div className="launching-widget">
        <div className="launch-left">
          <h3>🚀 Launching Soon in Lucknow · Kanpur · Allahabad · Indore</h3>
          <p className="sub">
            Join early for exclusive rewards — early users get ₹100 Seva Credit at launch.
          </p>
        </div>

        <form className="launch-form" onSubmit={handleSubmit}>
          <div className="row">
            <input
              name="name"
              value={form.name}
              onChange={handleChange}
              placeholder="Your name"
              required
            />

            <div className="phone-otp">
              <input
                name="phone"
                value={form.phone}
                onChange={handleChange}
                placeholder="Mobile number (10 digits)"
                required
              />
              {!otpSent ? (
                <button
                  type="button"
                  className="otp-btn"
                  onClick={handleSendOtpMock}
                >
                  Send OTP
                </button>
              ) : !otpVerified ? (
                <>
                  <input
                    className="otp-input"
                    placeholder="Enter OTP"
                    value={otp}
                    onChange={(e) => setOtp(e.target.value)}
                  />
                  <button
                    type="button"
                    className="otp-btn"
                    onClick={handleVerifyOtpMock}
                  >
                    Verify
                  </button>
                </>
              ) : (
                <span className="verified-badge">Verified ✓</span>
              )}
            </div>
          </div>

          <div className="row">
            <select
              name="district"
              value={form.district}
              onChange={handleChange}
            >
              {districts.map((d) => (
                <option key={d} value={d}>
                  {d}
                </option>
              ))}
            </select>

            <select name="role" value={form.role} onChange={handleChange}>
              <option>Customer</option>
              <option>Professional</option>
            </select>
          </div>

          <div className="row">
            <input
              name="email"
              value={form.email}
              onChange={handleChange}
              placeholder="Email (optional)"
            />
          </div>

          {error && <div className="error">{error}</div>}
          {saved && (
            <div className="success">
              🎉 Thank you! We’ll notify you when SevaSetu launches in your city.
            </div>
          )}

          <div className="row actions">
            <button type="submit" disabled={loading}>
              {loading ? "Joining..." : "Join Waitlist"}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
