import admin from "firebase-admin";
import fs from "fs";

// ✅ Load service account JSON manually (CJS-safe)
const serviceAccount = JSON.parse(fs.readFileSync("./serviceAccountKey.json", "utf8"));

admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
});

const db = admin.firestore();

async function cleanDuplicates() {
  console.log("🚀 Starting duplicate cleanup...");
  const snapshot = await db.collection("services").get();
  const allDocs = snapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() }));

  const seen = new Set();
  let deletedCount = 0;

  for (const doc of allDocs) {
    const key = `${(doc.category || "").toLowerCase().trim()}::${(doc.subService || doc.name || "").toLowerCase().trim()}`;
    if (seen.has(key)) {
      console.log(`🗑️ Deleting duplicate: ${doc.subService || doc.name} (${doc.id})`);
      await db.collection("services").doc(doc.id).delete();
      deletedCount++;
    } else {
      seen.add(key);
    }
  }

  console.log(`✅ Cleanup complete. Deleted ${deletedCount} duplicates.`);
  process.exit(0);
}

cleanDuplicates().catch((err) => {
  console.error("❌ Error during cleanup:", err);
  process.exit(1);
});
