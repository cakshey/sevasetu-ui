/**
 * 🔧 import-clean-services.js
 * Imports cleaned services.json into Firestore safely (no duplicates)
 */

import fs from "fs";
import admin from "firebase-admin";

// ✅ Read service account JSON using fs (compatible with CommonJS)
const serviceAccount = JSON.parse(fs.readFileSync("./serviceAccountKey.json", "utf8"));

// ✅ Initialize Firebase Admin SDK
admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
});

const db = admin.firestore();

// ✅ Read local services.json file
const rawData = fs.readFileSync("./services.json", "utf-8");
const servicesData = JSON.parse(rawData);

(async () => {
  console.log("🚀 Starting Firestore import...");

  for (const [category, subServices] of Object.entries(servicesData)) {
    console.log(`📁 Category: ${category}`);

    for (const s of subServices) {
      const { subService, price, remarks } = s;

      // Check for existing duplicate
      const querySnapshot = await db
        .collection("services")
        .where("category", "==", category)
        .where("name", "==", subService)
        .get();

      if (!querySnapshot.empty) {
        console.log(`⚠️ Skipped duplicate: ${subService}`);
        continue;
      }

      await db.collection("services").add({
        category,
        name: subService,
        price,
        remarks,
        createdAt: admin.firestore.FieldValue.serverTimestamp(),
      });

      console.log(`✅ Added: ${subService}`);
    }
  }

  console.log("🎉 Import complete! Clean data is now in Firestore.");
  process.exit(0);
})();
