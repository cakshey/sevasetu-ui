import admin from "firebase-admin";
import fs from "fs";

const serviceAccount = JSON.parse(fs.readFileSync("./serviceAccountKey.json", "utf8"));
admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
});

const db = admin.firestore();

async function deepCleanDuplicates() {
  console.log("🚀 Starting deep duplicate cleanup...");

  const snapshot = await db.collection("services").get();
  const allDocs = snapshot.docs.map((doc) => ({
    id: doc.id,
    ...doc.data(),
  }));

  const seen = new Map();
  let deletedCount = 0;

  for (const doc of allDocs) {
    const cat = (doc.category || "").toLowerCase().trim();
    const sub = (doc.subService || doc.name || "").toLowerCase().trim();

    if (!cat || !sub) continue;

    const key = `${cat}::${sub}`;

    if (seen.has(key)) {
      // 🗑️ Delete the duplicate
      console.log(`🗑️ Deleting duplicate: ${doc.category} → ${doc.subService} (${doc.id})`);
      await db.collection("services").doc(doc.id).delete();
      deletedCount++;
    } else {
      seen.set(key, doc.id);
    }
  }

  console.log(`✅ Cleanup complete. Deleted ${deletedCount} duplicates.`);
  process.exit(0);
}

deepCleanDuplicates().catch((err) => {
  console.error("❌ Error cleaning duplicates:", err);
  process.exit(1);
});
