/**
 * import-clean-services-v2.0.js
 * Compatible with all Node.js versions
 */

import admin from "firebase-admin";
import fs from "fs";

// ✅ Read service account JSON manually
const serviceAccount = JSON.parse(fs.readFileSync("./serviceAccountKey.json", "utf8"));

if (!admin.apps.length) {
  admin.initializeApp({
    credential: admin.credential.cert(serviceAccount),
  });
}


const db = admin.firestore();
const servicesFile = "./services.json";

console.log("🚀 Starting Firestore import (v2.0)...");

// ✅ Load services JSON
const rawData = fs.readFileSync(servicesFile);
const servicesData = JSON.parse(rawData);

let added = 0;
let skipped = 0;

async function importData() {
  for (const [category, items] of Object.entries(servicesData)) {
    console.log(`📁 Category: ${category}`);

    for (const sub of items) {
      const subService = sub.subService?.trim();

      if (!subService) continue;

      // 🔍 Check if already exists (duplicate check)
      const existing = await db
        .collection("services")
        .where("category", "==", category)
        .where("subService", "==", subService)
        .get();

      if (!existing.empty) {
        console.log(`⚠️ Skipped duplicate: ${subService}`);
        skipped++;
        continue;
      }

      // ✅ Add new document
      await db.collection("services").add({
        category,
        subService,
        price: sub.price || 0,
        remarks: sub.remarks || "",
        createdAt: new Date().toISOString(),
      });

      console.log(`✅ Added: ${subService}`);
      added++;
    }
  }

  console.log("\n🎯 Import Summary:");
  console.log(`✅ Added: ${added}`);
  console.log(`⚠️ Skipped: ${skipped}`);
  console.log(`📊 Total processed: ${added + skipped}`);
  console.log("🎉 Import complete! Clean, categorized data is in Firestore.\n");

  process.exit(0);
}

importData().catch((err) => {
  console.error("❌ Import failed:", err);
  process.exit(1);
});
