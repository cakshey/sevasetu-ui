import admin from "firebase-admin";
import fs from "fs";

// Load credentials
const serviceAccount = JSON.parse(fs.readFileSync("./serviceAccountKey.json", "utf8"));
admin.initializeApp({ credential: admin.credential.cert(serviceAccount) });

const db = admin.firestore();

async function finalCleanup() {
  console.log("🚀 Running final duplicate cleanup...");

  const snapshot = await db.collection("services").get();
  const allDocs = snapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() }));

  const seen = new Map();
  let deletedCount = 0;

  for (const doc of allDocs) {
    const category = (doc.category || "").toLowerCase().trim();
    const name = (doc.subService || doc.name || "").toLowerCase().trim();
    const price = doc.price ? doc.price.toString().trim() : "";
    const remarks = (doc.remarks || "").toLowerCase().trim();

    if (!category || !name) continue;

    const key = `${category}::${name}::${price}::${remarks}`;

    if (seen.has(key)) {
      console.log(`🗑️ Deleting duplicate → ${doc.category} > ${doc.subService}`);
      await db.collection("services").doc(doc.id).delete();
      deletedCount++;
    } else {
      seen.set(key, doc.id);
    }
  }

  console.log(`✅ Cleanup done. Deleted ${deletedCount} duplicates.`);
  console.log(`📊 Unique services remaining: ${seen.size}`);
  process.exit(0);
}

finalCleanup().catch((err) => {
  console.error("❌ Error in cleanup:", err);
  process.exit(1);
});
