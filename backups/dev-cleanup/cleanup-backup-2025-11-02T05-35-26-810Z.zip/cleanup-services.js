import admin from "firebase-admin";
import fs from "fs";

const serviceAccount = JSON.parse(fs.readFileSync("./serviceAccountKey.json", "utf8"));

if (!admin.apps.length) {
  admin.initializeApp({
    credential: admin.credential.cert(serviceAccount),
  });
}

const db = admin.firestore();

async function cleanupServices() {
  const snapshot = await db.collection("services").get();
  console.log(`🧹 Found ${snapshot.size} documents in 'services'...`);

  if (snapshot.empty) {
    console.log("✅ Nothing to delete — already clean!");
    process.exit(0);
  }

  const confirm = "yes"; // <-- change to "yes" when ready to delete
  if (confirm !== "yes") {
    console.log("❌ Cleanup cancelled (set confirm = 'yes' to proceed).");
    process.exit(0);
  }

  let count = 0;
  for (const doc of snapshot.docs) {
    await doc.ref.delete();
    count++;
    if (count % 10 === 0) console.log(`🗑️ Deleted ${count}...`);
  }

  console.log(`\n✅ Cleanup complete — deleted ${count} documents.`);
  process.exit(0);
}

cleanupServices().catch((err) => {
  console.error("❌ Error during cleanup:", err);
  process.exit(1);
});
