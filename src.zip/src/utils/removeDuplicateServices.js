// ✅ src/utils/removeDuplicateServices.js
import admin from "firebase-admin";
import fs from "fs";
import path from "path";

// Initialize Firebase Admin SDK
const serviceAccount = JSON.parse(
  fs.readFileSync(path.resolve("serviceAccountKey.json"), "utf8")
);

if (!admin.apps.length) {
  admin.initializeApp({
    credential: admin.credential.cert(serviceAccount),
  });
}

const db = admin.firestore();

async function removeDuplicates() {
  console.log("🧹 Starting Firestore duplicate cleanup...");

  const snapshot = await db.collection("services").get();
  const services = snapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() }));

  console.log(`📦 Total services found: ${services.length}`);

  // Map to track unique records
  const uniqueMap = new Map();
  const duplicates = [];

  for (const s of services) {
    const key = `${(s.category || "").trim().toLowerCase()}|${(s.name || s.subService || "").trim().toLowerCase()}|${s.price || 0}|${(s.description || s.remarks || "").trim().toLowerCase()}`;

    if (uniqueMap.has(key)) {
      duplicates.push(s.id);
    } else {
      uniqueMap.set(key, s.id);
    }
  }

  console.log(`⚠️ Found ${duplicates.length} duplicate services.`);

  if (duplicates.length === 0) {
    console.log("✅ No duplicates found!");
    return;
  }

  // Backup duplicates to JSON
  const backupFile = path.resolve(
    `backups/services-duplicates-${new Date().toISOString().split("T")[0]}.json`
  );
  fs.writeFileSync(backupFile, JSON.stringify(duplicates, null, 2));
  console.log(`💾 Backup created: ${backupFile}`);

  // Delete duplicates
  let deletedCount = 0;
  for (const id of duplicates) {
    await db.collection("services").doc(id).delete();
    deletedCount++;
  }

  console.log(`✅ Deleted ${deletedCount} duplicates successfully!`);
}

removeDuplicates()
  .then(() => {
    console.log("🎯 Cleanup complete!");
    process.exit(0);
  })
  .catch((err) => {
    console.error("❌ Error cleaning duplicates:", err);
    process.exit(1);
  });
